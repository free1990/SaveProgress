#import <UIKit/UIKit.h>

@interface TGInteractiveNavigationTransition : UIPercentDrivenInteractiveTransition

@end
