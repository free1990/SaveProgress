#import "PSCoding.h"

@interface TGDocumentAttributeSticker : NSObject <PSCoding, NSCoding>

@end
