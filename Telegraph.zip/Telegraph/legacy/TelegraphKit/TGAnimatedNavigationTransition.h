#import <UIKit/UIKit.h>

@interface TGAnimatedNavigationTransition : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic, assign) BOOL dismissal;

@end
