#import "TGInteractiveNavigationTransition.h"

@interface TGInteractiveNavigationTransition ()
{
}

@end

@implementation TGInteractiveNavigationTransition

@end
