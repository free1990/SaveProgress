#import <UIKit/UIKit.h>

@interface TGPopoverController : UIPopoverController

- (void)setContentSize:(CGSize)contentSize;

@end
