#import "TGFakeInputView.h"

@implementation TGFakeInputView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {

    }
    return self;
}



@end
