#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_Photo : NSObject <TLVector>


@end

