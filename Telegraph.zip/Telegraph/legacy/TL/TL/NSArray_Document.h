#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_Document : NSObject <TLVector>


@end

