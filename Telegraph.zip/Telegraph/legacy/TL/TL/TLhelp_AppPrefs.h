#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLhelp_AppPrefs : NSObject <TLObject>

@property (nonatomic, retain) NSData *bytes;

@end

@interface TLhelp_AppPrefs$help_appPrefs : TLhelp_AppPrefs


@end

