#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_ContactRequest : NSObject <TLVector>


@end

