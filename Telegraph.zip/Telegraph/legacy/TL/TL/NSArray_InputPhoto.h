#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_InputPhoto : NSObject <TLVector>


@end

