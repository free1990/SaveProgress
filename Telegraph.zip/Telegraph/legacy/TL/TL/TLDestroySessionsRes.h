#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLDestroySessionsRes : NSObject <TLObject>

@property (nonatomic, retain) NSArray *destroy_results;

@end

@interface TLDestroySessionsRes$destroy_sessions_res : TLDestroySessionsRes


@end

