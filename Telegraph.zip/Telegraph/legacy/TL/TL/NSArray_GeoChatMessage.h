#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_GeoChatMessage : NSObject <TLVector>


@end

