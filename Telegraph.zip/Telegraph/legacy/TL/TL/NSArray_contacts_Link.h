#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_contacts_Link : NSObject <TLVector>


@end

