#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_DocumentAttribute : NSObject <TLVector>


@end

