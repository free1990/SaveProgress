#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_Contact : NSObject <TLVector>


@end

