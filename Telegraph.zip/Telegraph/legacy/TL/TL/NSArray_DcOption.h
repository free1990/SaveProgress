#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_DcOption : NSObject <TLVector>


@end

