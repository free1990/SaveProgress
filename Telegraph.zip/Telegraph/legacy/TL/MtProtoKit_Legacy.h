//
//  MTProtoKit.h
//  MTProtoKit
//
//  Created by Peter on 15/02/14.
//  Copyright (c) 2014 Telegram LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MTProtoKit : NSObject

@end
