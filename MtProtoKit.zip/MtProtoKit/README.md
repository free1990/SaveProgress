MtProtoKit
==========

Universal MTProto framework for both iOS and OS X
